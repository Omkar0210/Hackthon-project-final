import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, Zap, Users, MessageCircle, Phone } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20">
      {/* Header */}
      <header className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold text-lg">
              C
            </div>
            <span className="font-bold text-xl text-foreground">CuraLink</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-muted-foreground hover:text-foreground transition">
              Features
            </Link>
            <Link href="#how-it-works" className="text-muted-foreground hover:text-foreground transition">
              How it Works
            </Link>
            <Link href="/auth" className="text-muted-foreground hover:text-foreground transition">
              Sign In
            </Link>
            <Link href="/auth?mode=signup">
              <Button>Get Started</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main className="pt-32 pb-20">
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-20">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Connect Patients with Clinical Trials
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-balance">
            CuraLink bridges the gap between patients seeking treatment and researchers advancing medical science. Find
            trials, connect with experts, and make an impact.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth?mode=signup">
              <Button size="lg" className="gap-2">
                Join as Patient <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/auth?mode=signup&role=researcher">
              <Button size="lg" variant="outline">
                Join as Researcher
              </Button>
            </Link>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">Why CuraLink?</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="p-6 hover:shadow-lg transition">
              <Zap className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Smart Matching</h3>
              <p className="text-muted-foreground">AI-powered trial recommendations based on your health profile</p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition">
              <Users className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Direct Access</h3>
              <p className="text-muted-foreground">Connect directly with lead researchers and coordinators</p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition">
              <MessageCircle className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Real-time Communication</h3>
              <p className="text-muted-foreground">Chat, SMS, and voice updates about your trial progress</p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition">
              <Phone className="w-8 h-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">24/7 Support</h3>
              <p className="text-muted-foreground">Voice agent available for questions anytime</p>
            </Card>
          </div>
        </section>

        {/* How it Works */}
        <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <h2 className="text-3xl font-bold text-foreground mb-12 text-center">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mx-auto mb-4">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2">Create Profile</h3>
              <p className="text-muted-foreground">Share your health information securely</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mx-auto mb-4">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2">Get Matched</h3>
              <p className="text-muted-foreground">Discover trials perfectly suited for you</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mx-auto mb-4">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2">Participate</h3>
              <p className="text-muted-foreground">Connect with researchers and contribute to science</p>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Card className="p-12 bg-primary text-primary-foreground">
            <h2 className="text-3xl font-bold mb-4">Ready to Make a Difference?</h2>
            <p className="mb-6 text-primary-foreground/90">
              Join thousands of patients and researchers advancing medical science together.
            </p>
            <Link href="/auth?mode=signup">
              <Button size="lg" variant="secondary">
                Get Started Now
              </Button>
            </Link>
          </Card>
        </section>
      </main>
    </div>
  )
}
