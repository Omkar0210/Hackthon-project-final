"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LogOut, Search, MessageSquare, Phone, Users } from "lucide-react"
import Link from "next/link"

interface User {
  id: string
  name: string
  email: string
  role: string
}

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const userStr = localStorage.getItem("user")
    const token = localStorage.getItem("token")

    if (!userStr || !token) {
      router.push("/auth")
    } else {
      setUser(JSON.parse(userStr))
      setLoading(false)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Welcome, {user?.name}!</h1>
            <p className="text-sm text-muted-foreground capitalize">{user?.role} Dashboard</p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="gap-2 bg-transparent">
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {user?.role === "patient" ? (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Find Trials */}
            <Link href="/trials">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer h-full">
                <Search className="w-8 h-8 text-primary mb-4" />
                <h2 className="text-2xl font-bold mb-2">Find Clinical Trials</h2>
                <p className="text-muted-foreground mb-4">Discover trials matching your health profile and interests</p>
                <Button className="w-full">Browse Trials</Button>
              </Card>
            </Link>

            {/* My Trials */}
            <Link href="/my-trials">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer h-full">
                <MessageSquare className="w-8 h-8 text-accent mb-4" />
                <h2 className="text-2xl font-bold mb-2">My Trials</h2>
                <p className="text-muted-foreground mb-4">
                  Track your enrolled trials and communicate with researchers
                </p>
                <Button className="w-full">View My Trials</Button>
              </Card>
            </Link>

            {/* Chat Support */}
            <Link href="/chat">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <MessageSquare className="w-8 h-8 text-secondary mb-4" />
                <h2 className="text-2xl font-bold mb-2">Chat Support</h2>
                <p className="text-muted-foreground mb-4">Message researchers and get support</p>
                <Button className="w-full" variant="secondary">
                  Start Chat
                </Button>
              </Card>
            </Link>

            {/* Voice Agent */}
            <Link href="/voice-agent">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <Phone className="w-8 h-8 text-destructive mb-4" />
                <h2 className="text-2xl font-bold mb-2">Voice Assistant</h2>
                <p className="text-muted-foreground mb-4">Call our AI assistant for 24/7 support</p>
                <Button className="w-full" variant="destructive">
                  Call Now
                </Button>
              </Card>
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {/* My Trials */}
            <Link href="/researcher/trials">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <Search className="w-8 h-8 text-primary mb-4" />
                <h2 className="text-2xl font-bold mb-2">My Trials</h2>
                <p className="text-muted-foreground mb-4">Manage your clinical trials and participants</p>
                <Button className="w-full">Manage Trials</Button>
              </Card>
            </Link>

            {/* Find Participants */}
            <Link href="/researcher/participants">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <Users className="w-8 h-8 text-accent mb-4" />
                <h2 className="text-2xl font-bold mb-2">Find Participants</h2>
                <p className="text-muted-foreground mb-4">Connect with patients interested in your research</p>
                <Button className="w-full">Find Participants</Button>
              </Card>
            </Link>

            {/* Messages */}
            <Link href="/chat">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <MessageSquare className="w-8 h-8 text-secondary mb-4" />
                <h2 className="text-2xl font-bold mb-2">Messages</h2>
                <p className="text-muted-foreground mb-4">Communicate with trial participants</p>
                <Button className="w-full" variant="secondary">
                  View Messages
                </Button>
              </Card>
            </Link>

            {/* Settings */}
            <Link href="/settings">
              <Card className="p-8 hover:shadow-lg transition cursor-pointer">
                <Phone className="w-8 h-8 text-destructive mb-4" />
                <h2 className="text-2xl font-bold mb-2">Settings</h2>
                <p className="text-muted-foreground mb-4">Configure messaging and notification preferences</p>
                <Button className="w-full" variant="destructive">
                  Configure
                </Button>
              </Card>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
