"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Search, MapPin, Users, Clock } from "lucide-react"

interface Trial {
  _id: string
  title: string
  description: string
  status: string
  location: string
  phase: string
  sponsor: string
  participantsNeeded: number
  startDate: string
  endDate: string
}

export default function TrialsPage() {
  const [trials, setTrials] = useState<Trial[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mock data - in production, fetch from API
    setTrials([
      {
        _id: "1",
        title: "Diabetes Management Study",
        description: "A groundbreaking study on new insulin therapy",
        status: "Recruiting",
        location: "New York, NY",
        phase: "Phase III",
        sponsor: "MedCorp Research",
        participantsNeeded: 100,
        startDate: "2024-06-01",
        endDate: "2025-12-31",
      },
      {
        _id: "2",
        title: "Alzheimer's Prevention Trial",
        description: "Testing preventive measures for cognitive decline",
        status: "Recruiting",
        location: "Boston, MA",
        phase: "Phase II",
        sponsor: "Brain Health Institute",
        participantsNeeded: 50,
        startDate: "2024-07-15",
        endDate: "2025-06-30",
      },
      {
        _id: "3",
        title: "Cancer Immunotherapy Study",
        description: "Novel approach to cancer treatment",
        status: "Recruiting",
        location: "San Francisco, CA",
        phase: "Phase I",
        sponsor: "Oncology Innovations",
        participantsNeeded: 25,
        startDate: "2024-08-01",
        endDate: "2026-01-31",
      },
    ])
    setLoading(false)
  }, [])

  const filteredTrials = trials.filter(
    (trial) =>
      trial.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      trial.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/dashboard" className="text-primary hover:underline mb-4 inline-block">
            ← Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-foreground">Find Clinical Trials</h1>
          <p className="text-muted-foreground mt-2">Discover trials that match your health profile</p>
        </div>
      </header>

      {/* Search */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search trials by name or condition..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Trials Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading trials...</p>
          </div>
        ) : filteredTrials.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No trials found matching your search</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrials.map((trial) => (
              <Card key={trial._id} className="p-6 hover:shadow-lg transition flex flex-col">
                <div className="flex-1">
                  <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full mb-2">
                    {trial.phase}
                  </div>
                  <h3 className="text-lg font-semibold mb-2 line-clamp-2">{trial.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{trial.description}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {trial.location}
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="w-4 h-4" />
                      {trial.participantsNeeded} spots available
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {trial.status}
                    </div>
                  </div>
                </div>
                <Button className="w-full mt-4">Learn More</Button>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
