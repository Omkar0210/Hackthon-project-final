"use client"

import { useEffect, useState } from "react"
import { Phone, PhoneOff, Loader } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { initializeVapi, startVoiceCall, VAPI_CONFIG } from "@/lib/vapi"

interface VoiceAgentWidgetProps {
  patientName?: string
  patientEmail?: string
  trialId?: string
  className?: string
}

export function VoiceAgentWidget({ patientName, patientEmail, trialId, className = "" }: VoiceAgentWidgetProps) {
  const [vapiClient, setVapiClient] = useState<any>(null)
  const [isCallActive, setIsCallActive] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [callStatus, setCallStatus] = useState<string>("Ready to call")
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Initialize VAPI on component mount
    const setupVapi = async () => {
      try {
        const client = await initializeVapi()
        setVapiClient(client)
      } catch (err) {
        setError("Failed to initialize voice assistant")
        console.error("[v0] VAPI initialization error:", err)
      }
    }

    setupVapi()
  }, [])

  const handleStartCall = async () => {
    if (!vapiClient) {
      setError("Voice assistant not ready. Please refresh the page.")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      console.log("[v0] Starting voice call with patient:", patientName)
      const call = await startVoiceCall(vapiClient, {
        name: patientName,
        email: patientEmail,
        trialId,
      })

      setIsCallActive(true)
      setCallStatus("Call in progress...")
      console.log("[v0] Voice call started:", call)
    } catch (err) {
      setError("Failed to start voice call. Try again.")
      console.error("[v0] Error starting call:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleStopCall = async () => {
    if (!vapiClient) return

    try {
      console.log("[v0] Stopping voice call")
      setIsCallActive(false)
      setCallStatus("Call ended")
      // Note: In production, you'd have access to the call ID to stop it properly
      setCallStatus("Ready to call")
    } catch (err) {
      console.error("[v0] Error stopping call:", err)
      setError("Failed to end call")
    }
  }

  return (
    <Card className={`p-6 ${className}`}>
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold text-lg mb-2">AI Voice Assistant</h3>
          <p className="text-sm text-muted-foreground">{VAPI_CONFIG.assistantName}</p>
        </div>

        <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isCallActive ? "bg-green-500 animate-pulse" : "bg-gray-400"}`} />
            <span className="text-sm font-medium">{callStatus}</span>
          </div>
        </div>

        {error && <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-700">{error}</div>}

        <div className="flex gap-2">
          {!isCallActive ? (
            <Button onClick={handleStartCall} disabled={isLoading || !vapiClient} className="flex-1 gap-2" size="sm">
              {isLoading ? <Loader className="w-4 h-4 animate-spin" /> : <Phone className="w-4 h-4" />}
              Start Voice Call
            </Button>
          ) : (
            <Button onClick={handleStopCall} variant="destructive" className="flex-1 gap-2" size="sm">
              <PhoneOff className="w-4 h-4" />
              End Call
            </Button>
          )}
        </div>

        <p className="text-xs text-muted-foreground">
          Ask our AI assistant about trials, your health profile, or get appointment reminders.
        </p>
      </div>
    </Card>
  )
}
